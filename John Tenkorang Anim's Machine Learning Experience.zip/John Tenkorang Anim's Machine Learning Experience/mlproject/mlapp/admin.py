from django.contrib import admin
from .models import Data

class DataAdmin(admin.ModelAdmin):
    list_display = ('Sepal_Length', 'Sepal_Width', 'Petal_Length', 'Petal_Width', 'Species')
# Register your models here.
admin.site.register(Data, DataAdmin)