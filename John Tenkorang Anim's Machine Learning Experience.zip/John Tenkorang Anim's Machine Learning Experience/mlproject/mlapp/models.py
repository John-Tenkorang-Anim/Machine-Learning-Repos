from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from keras.models import load_model
import numpy as np

# model = load_model()
# Create your models here.
class Data(models.Model):
    Sepal_Length = models.FloatField(validators=[MinValueValidator(2),MaxValueValidator(3)])
    Sepal_Width = models.FloatField()
    Petal_Length = models.FloatField()
    Petal_Width = models.FloatField()
    Species = models.FloatField(blank=True, null=True)

    def save(self, *args, **kwargs):
        # self.Species = np.argmax(model.predict([[self.Sepal_Length,self.Sepal_Width,self.Petal_Length,self.Petal_Width]])) 
        self.Species = 2
        return super().save(*args, **kwargs)