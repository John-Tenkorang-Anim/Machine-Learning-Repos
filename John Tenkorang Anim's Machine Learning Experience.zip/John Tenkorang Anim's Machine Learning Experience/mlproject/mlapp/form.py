from django import forms
from .models import Data

class DataForm(forms.ModelForm):
    class Meta:
        model = Data
        fields = ['Sepal_Length', 'Sepal_Width', 'Petal_Length', 'Petal_Width', 'Species']