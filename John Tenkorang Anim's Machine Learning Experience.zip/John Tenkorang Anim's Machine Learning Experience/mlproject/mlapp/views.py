from django.shortcuts import render
from .form import DataForm

# Create your views here.
def index(request):
    if request.method=='POST':
        form = DataForm(request.POST)
        if form.is_valid():
            form.save()
    form = DataForm()
    context = {
        'form': form
    }
    return render(request, 'index.html')