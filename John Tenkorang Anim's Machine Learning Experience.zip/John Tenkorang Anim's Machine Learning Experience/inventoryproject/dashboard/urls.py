from django import path
from . import views
urlspatterns =[
    path('index/', views.index, name='index')
]
